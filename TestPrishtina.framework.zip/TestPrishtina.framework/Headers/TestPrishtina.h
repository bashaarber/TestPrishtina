//
//  TestPrishtina.h
//  TestPrishtina
//
//  Created by Arber on 4.3.21.
//

#import <Foundation/Foundation.h>

//! Project version number for TestPrishtina.
FOUNDATION_EXPORT double TestPrishtinaVersionNumber;

//! Project version string for TestPrishtina.
FOUNDATION_EXPORT const unsigned char TestPrishtinaVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <TestPrishtina/PublicHeader.h>


